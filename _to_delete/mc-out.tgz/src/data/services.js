/* ═══════════════════════════════════════════════════════════
   MANHAR CREATIVES — Service Catalogue
   Single source of truth for service pages, home sections,
   navigation, footer, sitemap and JSON-LD structured data.
   ═══════════════════════════════════════════════════════════ */

export const SERVICES = [
  /* ─────────────────────────────────────────────────────── */
  {
    id: 'web-dev',
    slug: 'website-development',
    category: 'WEB DEV',
    icon: '◈',
    title: 'Website Development',
    shortTitle: 'Website Development',
    tagline: 'Professional websites built for credibility.',
    description:
      'Custom websites designed to showcase your business, strengthen trust, and create a professional digital presence. Every website is built with clarity, performance, and user experience in mind.',
    image: '/images/services/web-dev.webp',
    layout: 'left',
    features: [
      'Business Websites',
      'Corporate Websites',
      'Landing Pages',
      'Portfolio Websites',
      'Startup Websites',
    ],

    /* ── Imagery ──────────────────────────────────────────
       Every slot is a real file path. Replacing the artwork is
       dropping a new .webp over the same filename — no code
       change, no import to update, nothing to rebuild by hand.
       See docs/image-brief.md for the prompt behind each one.
    ───────────────────────────────────────────────────── */
    media: {
      hero: '/images/services/web-dev/hero.webp',
      problem: '/images/services/web-dev/problem.webp',
      approach: '/images/services/web-dev/approach.webp',
      local: '/images/services/web-dev/local.webp',
      faq: '/images/services/web-dev/faq.webp',
    },

    /* ── Page-level content ── */
    metaTitle: 'Website Development Company in Gujarat | Custom Web Design — Manhar Creatives',
    metaDescription:
      'Custom website development for businesses in Ahmedabad, Mehsana, Visnagar and across India. Fast, mobile-first, SEO-ready business websites, landing pages and corporate sites built to convert visitors into customers.',
    keywords: [
      'website development company',
      'custom website design',
      'business website development',
      'corporate website design',
      'landing page development',
      'responsive web design',
      'react website development',
      'seo friendly website',
      'website redesign services',
      'fast loading website',
    ],

    hero: {
      title: 'Website development for businesses',
      accent: 'that are tired of being overlooked',
      subtitle:
        'A visitor decides in **roughly eight seconds** whether your business looks worth contacting. We build the website that makes those eight seconds work in your favour — fast on every phone, clear about what you do, and structured so the right people reach you instead of scrolling past.',
    },

    heroStats: [
      { value: '2–6', label: 'Weeks to launch' },
      { value: '70%+', label: 'Of your visitors arrive on a phone' },
      { value: '8 sec', label: 'To earn the first impression' },
    ],

    problem: {
      heading: 'Every day, your website quietly hands people to your competitor',
      body: [
        'Someone hears your name. They do not call — they search. Your site loads, and for the first few seconds they are not reading it, they are **judging** it: does this look like a business that can be trusted with my money, my project, my deadline?',
        'If the page is slow, cramped on their phone, or vague about what you actually do, they leave. They do not complain. They do not fill in the form. They **open the next tab** and call the competitor whose website answered faster. You never see it happen — you only see the enquiries that never arrived.',
      ],
      points: [
        '**Eight seconds.** That is the window you get before a visitor decides to stay or go',
        'More than **70% of your traffic is on a phone** — a desktop-first site loses most of them before it finishes loading',
        'A **three-second load** pushes you down Google and sends users straight back to the search results',
        'Traffic with no clear next step is **just a bill** — visits that never turn into a single enquiry',
        'A dated design quietly tells a buyer the **business behind it is dated too**',
      ],
    },

    solution: {
      heading: 'We do not build websites. We build the reason someone chooses you.',
      body: [
        'A website is not a design deliverable. It is the room where a buying decision happens — usually long before you speak to the person making it. So we start where the decision starts: who is landing here, what they need to believe before they contact you, and the one action that matters more than the rest.',
        'Structure, message hierarchy, speed and SEO foundations are built **together**, in that order of priority. Visual design comes once the argument is right — because a beautiful page that does not answer the visitor question is just an **expensive brochure**.',
      ],
      pillars: [
        {
          title: 'Decision-first structure',
          desc: 'Sitemap, page order and messaging mapped to how your customer actually decides — not to what looks tidy in a navigation menu.',
        },
        {
          title: 'Fast by construction',
          desc: 'Performance is a build decision, not a cleanup task. Optimised media, minimal blocking scripts and Core Web Vitals handled during development.',
        },
        {
          title: 'Found, then trusted',
          desc: 'Semantic structure, schema and clean URLs so Google can read it — and a design that makes a human want to stay once it has.',
        },
      ],
      quote: 'We design, we build, you grow. The website is where that sentence has to start proving itself.',
    },

    deliverables: [
      {
        title: 'Strategy & Structure',
        desc: 'Before a single pixel is drawn, we decide what the site has to **prove** and in what order. Sitemap, page hierarchy, messaging structure and the conversion path are written down and agreed.',
        points: [
          'Customer, objection and decision mapping',
          'Sitemap and page-by-page content outline',
          'One primary action defined per page',
        ],
        image: '/images/services/web-dev/01-strategy.webp',
      },
      {
        title: 'Custom Interface Design',
        desc: 'A design system built for **your** brand — typography, colour, spacing and components that belong to you. Not a template with your logo dropped into the corner.',
        points: [
          'Desktop, tablet and mobile layouts designed, not guessed',
          'Reusable component set for future pages',
          'Brand colour and type system applied consistently',
        ],
        image: '/images/services/web-dev/02-design.webp',
      },
      {
        title: 'Responsive Development',
        desc: 'Hand-built, mobile-first front-end that behaves correctly on **every screen a real customer owns** — including the five-year-old Android on a weak signal.',
        points: [
          'Mobile-first build, expanded to desktop',
          'Tested across browsers and real device widths',
          'Accessible markup, keyboard and screen-reader safe',
        ],
        image: '/images/services/web-dev/03-development.webp',
      },
      {
        title: 'Performance Engineering',
        desc: 'Speed is not a setting you switch on at the end. Media, fonts, scripts and loading order are handled during the build so the site is **fast on the first visit**, not just on yours.',
        points: [
          'Optimised, correctly sized and lazy-loaded media',
          'Core Web Vitals measured before handover',
          'No bloated plugin stack quietly slowing you down',
        ],
        image: '/images/services/web-dev/04-performance.webp',
      },
      {
        title: 'On-Page SEO Foundation',
        desc: 'The technical groundwork ranking depends on — **built in, not sold back to you later** as a separate package once the site is already live.',
        points: [
          'Semantic HTML, heading structure and meta setup',
          'Schema markup, sitemap, robots and clean URLs',
          'Local SEO structure for city and service pages',
        ],
        image: '/images/services/web-dev/05-seo.webp',
      },
      {
        title: 'Analytics, Handover & Support',
        desc: 'You leave the project **owning it** — the code, the domain, the hosting, the data and the knowledge to run it. Plus support after launch, not silence after handover.',
        points: [
          'Analytics, Search Console and Tag Manager configured',
          'Recorded walkthrough and written documentation',
          'Post-launch support window included',
        ],
        image: '/images/services/web-dev/06-handover.webp',
      },
    ],

    /* Plain list kept for the home page and structured data. */
    tech: ['React', 'Next.js', 'Vite', 'Tailwind CSS', 'Node.js', 'WordPress', 'Vercel', 'Cloudflare'],

    techStack: [
      {
        name: 'React',
        role: 'Interface layer',
        logo: '/images/tech/react.webp',
        points: [
          'Component architecture so new pages reuse proven parts',
          'Keeps large sites fast as sections are added over time',
        ],
      },
      {
        name: 'Next.js',
        role: 'Rendering & SEO',
        logo: '/images/tech/nextjs.webp',
        points: [
          'Server rendering so Google sees full content, not an empty shell',
          'Used when a site needs scale, routing depth or a blog engine',
        ],
      },
      {
        name: 'Vite',
        role: 'Build tooling',
        logo: '/images/tech/vite.webp',
        points: [
          'Ships lean production bundles — less code for your visitor to download',
          'Fast iteration during the build, so review cycles stay short',
        ],
      },
      {
        name: 'Tailwind CSS',
        role: 'Design system',
        logo: '/images/tech/tailwind.webp',
        points: [
          'Enforces one spacing and colour scale across every page',
          'Keeps the stylesheet small instead of growing with each new section',
        ],
      },
      {
        name: 'Node.js',
        role: 'Server & APIs',
        logo: '/images/tech/nodejs.webp',
        points: [
          'Powers forms, integrations and anything the site has to talk to',
          'Same language across front and back end — faster to maintain',
        ],
      },
      {
        name: 'WordPress',
        role: 'Content management',
        logo: '/images/tech/wordpress.webp',
        points: [
          'Chosen when your team needs to publish without calling a developer',
          'Built lean and hardened — not a theme stacked with twenty plugins',
        ],
      },
      {
        name: 'Vercel',
        role: 'Hosting & delivery',
        logo: '/images/tech/vercel.webp',
        points: [
          'Global edge delivery so the site loads fast outside your city too',
          'Every deploy is previewable and reversible',
        ],
      },
      {
        name: 'Cloudflare',
        role: 'Security & speed',
        logo: '/images/tech/cloudflare.webp',
        points: [
          'CDN caching, DDoS protection and SSL handled properly',
          'Image and asset optimisation at the network edge',
        ],
      },
    ],

    local: {
      heading: 'Built in Gujarat, delivered across India',
      body:
        'We are based in Visnagar and build websites for businesses across Ahmedabad, Mehsana, North Gujarat and the rest of India. Local means you can **sit across a table** when that helps the project — and everything else runs over calls, WhatsApp and shared documents, at the pace your business actually moves.',
      points: [
        'You talk to the people doing the work, not an account manager',
        'Written scope and fixed pricing before anything starts',
        'You own the code, domain, hosting and data',
        'Support after launch, not silence after handover',
      ],
      stat: { value: 'Visnagar', label: 'Based in North Gujarat, working nationwide' },
    },

    faqNote:
      'These are the questions that come up in almost every first call. If yours is not here, **ask it directly** — you will get a straight answer, not a sales pitch.',

    faqs: [
      {
        q: 'How long does it take to build a business website?',
        a: 'Realistically, a minimum of two weeks. A focused landing page or a small business site is typically ready in 2 to 3 weeks. A larger multi-page corporate site with custom sections, content work and integrations usually runs 4 to 6 weeks. Anyone promising a serious website in three days is either using a template or skipping the parts that make it work. You get a written timeline before we begin.',
      },
      {
        q: 'Will my website work properly on mobile?',
        a: 'Yes. Every site we build is designed mobile-first and tested across real phone widths, tablets and desktop browsers. Since most of your visitors arrive on a phone, the mobile experience is designed first and the desktop layout is expanded from it — not the other way around, which is how most sites end up cramped on the screen that matters most.',
      },
      {
        q: 'Do you build websites that rank on Google?',
        a: 'We build the technical foundation ranking depends on — semantic structure, fast loading, schema markup, clean URLs, sitemaps and mobile usability. That is the part a developer controls. Rankings also depend on content, local signals and consistency over months, which we can support through ongoing SEO and content work. We will tell you honestly which of the two your business actually needs.',
      },
      {
        q: 'Can I update the website myself after launch?',
        a: 'Yes. Depending on the build we either connect a content management system or provide a simple editing workflow, plus a recorded handover walkthrough. If you would rather not manage it at all, we offer ongoing maintenance — but that is your choice, not a lock-in.',
      },
      {
        q: 'What does a website cost?',
        a: 'Cost follows scope — number of pages, custom functionality, content requirements and integrations. We scope the project first and share a fixed quote before starting, so there is no mid-project surprise. If your budget is better spent on something other than a new website, we will say so.',
      },
      {
        q: 'What do you need from me to start?',
        a: 'A conversation about what the business needs to achieve, whatever brand assets you already have, and a point of contact who can approve decisions. Content and photography can come from you or from us — we will tell you which parts genuinely need your input and which we can handle without holding up the build.',
      },
    ],

    related: ['branding', 'digital-presence', 'custom-software'],
  },

  /* ─────────────────────────────────────────────────────── */
  {
    id: 'custom-software',
    slug: 'custom-software-development',
    category: 'SOFTWARE',
    icon: '⬡',
    title: 'Custom Software Development',
    shortTitle: 'Custom Software',
    tagline: 'Software built around how your business actually runs.',
    description:
      'Custom CRM, ERP modules, internal dashboards, admin panels and business automation tools built around your exact workflow — replacing scattered spreadsheets and manual processes with one reliable system.',
    image: '/images/services/custom-software.webp',
    layout: 'right',
    features: [
      'Custom CRM Systems',
      'Business Automation',
      'Admin Dashboards',
      'Internal Tools',
      'API & System Integration',
    ],

    /* ── Imagery ──────────────────────────────────────────
       Every slot is a real file path. Replacing the artwork is
       dropping a new .webp over the same filename — no code
       change, no import to update, nothing to rebuild by hand.
       See docs/image-brief.md for the prompt behind each one.
    ───────────────────────────────────────────────────── */
    media: {
      hero: '/images/services/custom-software/hero.webp',
      problem: '/images/services/custom-software/problem.webp',
      approach: '/images/services/custom-software/approach.webp',
      local: '/images/services/custom-software/local.webp',
      faq: '/images/services/custom-software/faq.webp',
    },

    /* ── Page-level content ── */
    metaTitle: 'Custom Software & CRM Development Company in Gujarat — Manhar Creatives',
    metaDescription:
      'Custom software development, CRM systems, ERP modules, admin dashboards and business process automation built for Indian businesses. Replace spreadsheets and manual work with software designed around your workflow.',
    keywords: [
      'custom software development',
      'custom crm development',
      'crm software company',
      'erp software development',
      'business process automation',
      'internal tools development',
      'admin dashboard development',
      'inventory management software',
      'saas development company',
      'api integration services',
      'workflow automation software',
      'bespoke software development india',
    ],

    hero: {
      title: 'Custom software and CRM systems',
      accent: 'for the process you have already built',
      subtitle:
        'Your team already knows how the work gets done. The trouble is that the knowledge is spread across spreadsheets, WhatsApp threads and **one person’s memory** — and every handoff between them costs a few minutes and the occasional expensive mistake. We build the system that holds the process instead, so **the work happens once** and the numbers are ready before anyone asks for them.',
    },

    heroStats: [
      { value: '6–12', label: 'Weeks to a first working module' },
      { value: '₹0', label: 'Per-user licence once it is yours' },
      { value: '100%', label: 'Source code and data in your name' },
    ],

    problem: {
      heading: 'Every week, your team rebuilds the same information by hand',
      body: [
        'It starts sensibly. One Excel file for orders, a WhatsApp group for the field team, a second sheet for payments because the first one got messy. Then the business grows, and nobody notices the exact week those files stopped agreeing with each other. Now a simple question — what is actually pending with this customer — takes **four files and two phone calls** to answer.',
        'Meanwhile the off-the-shelf tool you bought covers about seventy per cent of the job. The rest is people re-typing data between systems, which is precisely where the errors live. You pay twice: once for the licence, and again for the hours spent **working around it**. And when the person who knows those workarounds takes leave, the process leaves with them.',
      ],
      points: [
        'The same order is entered **three times** — sales, dispatch and accounts each keep a copy',
        'Month-end takes days because the numbers must be **reconciled before they can be read**',
        'Ready-made tools force your process to **bend around their limits**, not the other way round',
        'Per-user licences climb with every hire — you are **renting the same software forever**',
        'Critical business knowledge sits in **one person’s laptop**, and walks out when they do',
      ],
    },

    solution: {
      heading: 'We build the version of your process that does not depend on anyone remembering.',
      body: [
        'So we start by sitting with the people who actually do the work, not only the owner. What gets written down, what gets skipped when the day is busy, which approvals are real and which are a formality. That map becomes the specification. Software built from an org chart looks tidy in a document and **gets abandoned in month two**.',
        'Then we build the smallest system that removes the most manual work, and put it in front of your team early. One module, live and genuinely useful, beats a full platform delivered in nine months and rejected in a week. Source code, database and hosting are in your name from the start, so the system stays **yours** whatever happens to our working relationship.',
      ],
      pillars: [
        {
          title: 'Mapped before built',
          desc: 'Every screen traces back to a real step in your operation, including the exceptions and shortcuts your team actually uses — not the process as written in the manual nobody opens.',
        },
        {
          title: 'Shipped in phases',
          desc: 'The most expensive manual process goes first and goes live on its own. You judge the software on whether it saved hours this month, not on a demo at the end of a long invoice.',
        },
        {
          title: 'Yours to keep',
          desc: 'Repository, database and hosting registered to you on day one. No per-user licence, no lock-in clause, no renewal that quietly funds somebody else’s product roadmap.',
        },
      ],
      quote:
        'We design, we build, you grow — and with software, growth means the same team handling twice the work without twice the effort.',
    },

    deliverables: [
      {
        title: 'Process Discovery',
        desc: 'A week or two spent watching how the work really moves — the registers, the forwarded messages, the file everyone duplicates before editing. What comes out is a written specification you can **read and disagree with** before a line of code exists.',
        points: [
          'Workflow walkthrough with the people doing the job',
          'Duplicate entry, bottlenecks and rework documented',
          'Written scope, module list and phase plan',
        ],
        image: '/images/services/custom-software/01-discovery.webp',
      },
      {
        title: 'System Architecture',
        desc: 'Data model, user roles and integration points are decided before development starts. Getting this stage wrong is what makes a system **expensive to change** two years later, when changing it matters most.',
        points: [
          'Database schema built for the reports you will want',
          'Role and permission structure mapped per department',
          'Integration and data migration plan agreed up front',
        ],
        image: '/images/services/custom-software/02-architecture.webp',
      },
      {
        title: 'Core CRM Build',
        desc: 'The first working module, usually lead capture, pipeline and follow-up, because that is where money leaks fastest. It goes live on its own so your team is **using it while the rest is still being built**.',
        points: [
          'Enquiry capture from website, phone and WhatsApp',
          'Pipeline stages named the way your team names them',
          'Follow-up reminders with full customer history',
        ],
        image: '/images/services/custom-software/03-crm.webp',
      },
      {
        title: 'Automation & Rules',
        desc: 'The repetitive parts stop needing a person. Invoices, reminders, approvals, stock alerts and scheduled reports run on their own, which quietly **removes the excuse for a late follow-up**.',
        points: [
          'Automated invoices, receipts and payment reminders',
          'Approval routing with a complete audit trail',
          'Scheduled reports delivered by email or WhatsApp',
        ],
        image: '/images/services/custom-software/04-automation.webp',
      },
      {
        title: 'Dashboards & Reporting',
        desc: 'Live numbers by role, so the owner, the sales head and the store keeper each open a different screen. No exports, no month-end wait — the answer is **already on the screen** when the question comes up.',
        points: [
          'Role-based dashboards for each department',
          'Sales, receivables, stock and staff performance views',
          'Excel and PDF exports for the people who still want them',
        ],
        image: '/images/services/custom-software/05-dashboards.webp',
      },
      {
        title: 'Migration & Handover',
        desc: 'Existing data is cleaned and moved in, staff are trained on their own screens, and the accounts are transferred to you. You finish the project **owning the system**, not renting access to it.',
        points: [
          'Data migration from spreadsheets and legacy software',
          'Role-wise training plus recorded walkthroughs',
          'Source code, database and hosting handed over',
        ],
        image: '/images/services/custom-software/06-handover.webp',
      },
    ],

    useCases: [
      {
        title: 'Sales & CRM',
        desc: 'Track every enquiry from first contact to closed deal, with automated follow-ups so no lead goes cold.',
      },
      {
        title: 'Inventory & Orders',
        desc: 'Live stock levels, purchase orders, supplier records and low-stock alerts across multiple locations.',
      },
      {
        title: 'Billing & Accounts',
        desc: 'Quotation to invoice to payment tracking, with GST-ready formats and automatic outstanding reminders.',
      },
      {
        title: 'Staff & Operations',
        desc: 'Attendance, task assignment, job cards, service scheduling and productivity reporting in one place.',
      },
      {
        title: 'Customer Portals',
        desc: 'Give clients a secure login to check order status, download invoices and raise requests without calling you.',
      },
      {
        title: 'Reporting & Analytics',
        desc: 'Management dashboards that answer real questions instantly instead of waiting for a month-end file.',
      },
    ],

    /* Plain list kept for the home page and structured data. */
    tech: [
      'React', 'Node.js', 'Python', 'PostgreSQL', 'MySQL', 'Supabase',
      'REST APIs', 'Next.js', 'Docker', 'AWS', 'Cloud Hosting',
    ],

    techStack: [
      {
        name: 'React',
        role: 'Application interface',
        logo: '/images/tech/react.webp',
        points: [
          'Keeps data-heavy tables, filters and entry forms quick at thousands of rows',
          'One component set reused across modules, so new screens match the old ones',
        ],
      },
      {
        name: 'Node.js',
        role: 'Application server',
        logo: '/images/tech/nodejs.webp',
        points: [
          'Runs the business rules, permissions and scheduled jobs behind every screen',
          'Handles live integrations with WhatsApp, payment gateways and existing software',
        ],
      },
      {
        name: 'Python',
        role: 'Data & automation',
        logo: '/images/tech/python.webp',
        points: [
          'Used to clean and import years of inconsistent spreadsheet data during migration',
          'Runs reconciliation jobs, bulk document generation and heavier reporting tasks',
        ],
      },
      {
        name: 'PostgreSQL',
        role: 'Primary database',
        logo: '/images/tech/postgresql.webp',
        points: [
          'Default choice when records relate to each other — orders, stock, ledgers, approvals',
          'Transaction safety, so a half-finished entry never corrupts your closing numbers',
        ],
      },
      {
        name: 'MySQL',
        role: 'Database alternative',
        logo: '/images/tech/mysql.webp',
        points: [
          'Chosen when your current systems or hosting already run on it',
          'Keeps migration simple instead of forcing a platform change you did not ask for',
        ],
      },
      {
        name: 'Supabase',
        role: 'Managed backend',
        logo: '/images/tech/supabase.webp',
        points: [
          'Shortens delivery on smaller internal tools — auth, storage and database without a server to maintain',
          'Postgres underneath, so data moves out cleanly if the tool outgrows it',
        ],
      },
      {
        name: 'REST APIs',
        role: 'System integration',
        logo: '/images/tech/restapis.webp',
        points: [
          'How your system talks to Tally, WhatsApp Business, payment gateways and your website',
          'Documented endpoints, so a future developer can extend it without guesswork',
        ],
      },
      {
        name: 'Next.js',
        role: 'Customer portals',
        logo: '/images/tech/nextjs.webp',
        points: [
          'Used for customer and vendor portals that sit outside the internal system',
          'Server rendering keeps public-facing pages fast and indexable when they need to be',
        ],
      },
      {
        name: 'Docker',
        role: 'Deployment consistency',
        logo: '/images/tech/docker.webp',
        points: [
          'The system behaves the same on our machines, the test server and your production one',
          'Changing hosting provider becomes a configuration task, not a rebuild',
        ],
      },
      {
        name: 'AWS',
        role: 'Cloud infrastructure',
        logo: '/images/tech/aws.webp',
        points: [
          'Deployed inside your own AWS account when you want control of the bill and the data',
          'Automated backups and snapshots, restore-tested before go-live rather than after',
        ],
      },
      {
        name: 'Cloud Hosting',
        role: 'Hosting & backups',
        logo: '/images/tech/cloudhosting.webp',
        points: [
          'Smaller systems run on right-sized Indian or regional servers to keep latency and cost down',
          'Monitoring, SSL and scheduled backups configured at setup, not assumed',
        ],
      },
    ],

    local: {
      heading: 'Built in North Gujarat, running in businesses across India',
      body:
        'We are based in Visnagar and build systems for businesses in Ahmedabad, Mehsana, across North Gujarat and the rest of India. For software this matters more than it does for a website — discovery works best **in your office, watching the actual work** — and the first fortnight after go-live is far easier when someone can be on a call at eight in the morning without a time-zone excuse.',
      points: [
        'Discovery done on site, where the process actually happens',
        'You talk to the people writing the code, not an account manager',
        'Written scope and fixed pricing per phase before development starts',
        'Repository, database and hosting accounts registered in your name',
      ],
      stat: { value: 'Visnagar', label: 'Based in North Gujarat, building for clients nationwide' },
    },

    faqNote:
      'Custom software is a heavier decision than a website, so these answers run longer. If the honest answer is that you should **not** build software this year, that is what you will hear on the call.',

    faqs: [
      {
        q: 'What is custom software development?',
        a: 'It is software built for one business instead of sold to thousands. The difference shows up in the details — your stage names, your approval rules, your GST formats, the exception you make for one large customer every month. A ready-made product handles the common eighty per cent well and leaves the rest to people. Custom becomes worth building when that remaining twenty per cent is where your hours, your errors and your margin quietly go.',
      },
      {
        q: 'Why build a custom CRM instead of buying a ready-made one?',
        a: 'Buy the ready-made one if your sales process looks like everybody else’s — a few stages, one team, standard reports. It will be live next week and cost far less than a build. Custom starts making sense when you are paying per user for features nobody opens, when your real process needs three fields the product will not add, or when your enquiry data only means something sitting next to inventory and billing. Somewhere around fifteen to twenty users, three years of per-seat fees often costs more than a focused custom build. Run that arithmetic before you decide anything.',
      },
      {
        q: 'How much does custom software cost in India?',
        a: 'Scope decides it, so any figure quoted before discovery is a guess dressed as a quote. What we can tell you is how the money behaves. A single focused module — a CRM, a job-card system, an inventory tool — is a project measured in lakhs, not tens of lakhs. A multi-department system covering sales, stock and accounts is several times that. We scope and price in phases, so you can fund the first module, check whether it saved the hours we claimed, and only then commit to the next. If a ₹3,000-a-month subscription genuinely solves the problem for another year, we will say that instead of quoting.',
      },
      {
        q: 'How long does a custom software project take?',
        a: 'Discovery is one to two weeks. From there, a focused first module is typically six to twelve weeks to people using it in production — and the last two of those weeks are usually testing and data migration, which nobody enjoys and everybody skips at their peril. Larger multi-module systems run across several months, delivered in phases that each work on their own. Anyone quoting a full ERP in six weeks is describing a demo, not a system your accounts team will trust at month end.',
      },
      {
        q: 'Can it integrate with the tools we already use?',
        a: 'Usually, yes. WhatsApp Business, Razorpay and other payment gateways, Google Workspace, Tally, Shopify and WooCommerce are connections we make regularly. Two honest caveats. Some Indian business software exposes no real API, and there the integration becomes a scheduled import and export rather than live sync — workable, but it is a file exchange and we will describe it as one. And some integrations carry their own platform charges, WhatsApp being the obvious example. Both get checked during discovery so the cost is on the table before you approve scope.',
      },
      {
        q: 'Who owns the software and the data?',
        a: 'You do, in writing. Source code lives in a repository in your name, the database sits in a hosting account you control, and credentials are handed to you at handover rather than kept until you ask. There is no per-user licence and nothing that prevents another developer from working on the system later. The one thing we ask is that you keep the documentation we hand over, because that is what makes the system maintainable by anyone, including us.',
      },
      {
        q: 'What happens if we stop working with you?',
        a: 'The system keeps running, which is the entire point of putting code, database and hosting in your name from day one. At the close of any engagement you receive the current source, a schema document, environment details and the deployment steps, so another developer can take over without reverse-engineering our decisions. We would rather keep a client because the work is good than because leaving is painful.',
      },
      {
        q: 'Is our business data secure?',
        a: 'Role-based access, encrypted connections, hashed passwords, audit logs on the records that matter, and automated backups that we restore-test before go-live — because an untested backup is not a backup. If your data is sensitive, or a client contract demands it, we deploy inside your own cloud account so nothing sits with us at all. What we will not claim is that any system is unbreakable. What we will do is make sure one staff member’s mistake cannot expose everything.',
      },
      {
        q: 'When should we not build custom software?',
        a: 'More often than you would expect a company that builds it to admit. If your process is standard and a subscription product already does it well, buy the product — accounting, payroll and email marketing are three places where building your own is almost always a mistake. If the real problem is that nobody follows the process, software will only help you make the same mess faster. And if the workflow is still changing every month, wait until it settles, or you will pay to build a moving target. Custom is the right call when the process is settled, specific to how you win business, and expensive to keep running by hand. We will tell you which of those you are in before quoting.',
      },
    ],

    related: ['web-dev', 'digital-presence', 'branding'],
  },

  /* ─────────────────────────────────────────────────────── */
  {
    id: 'branding',
    slug: 'branding-identity',
    category: 'BRANDING',
    icon: '✦',
    title: 'Branding & Identity',
    shortTitle: 'Branding & Identity',
    tagline: 'Professional identities that build trust.',
    description:
      'Strategic branding solutions that help businesses establish consistency, improve recognition, and create a strong professional image across digital and physical touchpoints.',
    image: '/images/services/branding.webp',
    layout: 'left',
    features: ['Logo Design', 'Brand Identity', 'Brand Guidelines', 'Visual Systems', 'Business Branding'],

    /* ── Imagery ──────────────────────────────────────────
       Every slot is a real file path. Replacing the artwork is
       dropping a new .webp over the same filename — no code
       change, no import to update, nothing to rebuild by hand.
       See docs/image-brief.md for the prompt behind each one.
    ───────────────────────────────────────────────────── */
    media: {
      hero: '/images/services/branding/hero.webp',
      problem: '/images/services/branding/problem.webp',
      approach: '/images/services/branding/approach.webp',
      local: '/images/services/branding/local.webp',
      faq: '/images/services/branding/faq.webp',
    },

    /* ── Page-level content ── */
    metaTitle: 'Branding Agency & Logo Design in Gujarat | Brand Identity — Manhar Creatives',
    metaDescription:
      'Professional brand identity design, logo design and brand guidelines for businesses in Ahmedabad, Mehsana and Visnagar. Build recognition, consistency and trust across every customer touchpoint.',
    keywords: [
      'branding agency',
      'logo design services',
      'brand identity design',
      'brand guidelines',
      'visual identity design',
      'corporate branding',
      'rebranding services',
      'brand strategy',
      'startup branding',
    ],

    hero: {
      title: 'Brand identity and logo design',
      accent: 'so the quality shows before you say a word',
      subtitle:
        'Most people meet your business long before they meet you — a board seen from a moving car, a bill handed across a counter, a forwarded screenshot. Each one is a **silent claim about how carefully you work**. We build the identity that makes the right claim every time: one mark, one palette, one set of rules that hold **whoever makes the next file**.',
    },

    heroStats: [
      { value: '3–5', label: 'Weeks from discovery to handover' },
      { value: '30+', label: 'Logo files across print and digital formats' },
      { value: '7–10', label: 'Years before a built identity needs revisiting' },
    ],

    problem: {
      heading: 'You keep losing work to businesses that are worse at the job',
      body: [
        'The logo was made in a hurry. Somebody’s cousin, a two-thousand-rupee job, a JPG that arrived on WhatsApp and has been stretched onto banners ever since. That was the correct decision at the time — there was no money and there was work to do. But the business has moved on **and the logo has not**, and it now quietly sets the price people expect to pay you.',
        'Then look at the competitor two streets away. Their work is not as good and everybody in the trade knows it. But their signboard, their bill book, their Instagram and their van all agree with each other, so a customer who cannot judge the work judges what they can see — and **decides they are the safer choice**. That is not a design problem. That is revenue walking across the road.',
      ],
      points: [
        'A logo that exists only as a **JPG made years ago** — no vector, no source file, no alternatives',
        'The colour on the board, the bill book and the Instagram feed are **three different colours**',
        'Every new design starts from zero because **nobody ever wrote the rules down**',
        'The printer redraws the mark by eye, and now **two versions are in circulation**',
        'Nothing in the identity says what you do better — you look **interchangeable with the next quotation**',
      ],
    },

    solution: {
      heading: 'A logo is a signature. The identity is the handwriting behind it.',
      body: [
        'So the work does not begin in a sketchbook. It begins with three questions: who you actually lose deals to, what a customer believes about you in the first four seconds, and the distance between the two. Design that skips those questions produces a mark that is **pleasant and says nothing** — and the business is back here in two years paying again.',
        'What gets built is a system. A primary mark with the variations real life demands, a palette with screen and print values that genuinely match, a type hierarchy, and written rules for the situations nobody plans for — a favicon, an embroidered shirt, a hoarding read at sixty kilometres an hour. Then all of it is handed over, **source files included**, so you are never negotiating for an editable version of your own logo.',
      ],
      pillars: [
        {
          title: 'Positioned, then drawn',
          desc: 'Who you are up against, what you are worth, and what a customer must believe within four seconds — settled on paper before a single mark is sketched.',
        },
        {
          title: 'Built for the hard applications',
          desc: 'Tested at favicon size, in one colour, embroidered on a shirt and stretched across a hoarding. A mark that only works centred on a white slide is not finished.',
        },
        {
          title: 'Rules that outlast us',
          desc: 'Written guidelines and organised files, so the next designer, the local sign vendor and your own staff produce the same brand without calling anyone.',
        },
      ],
      quote:
        'We design, we build, you grow — and with identity, growth means finally being able to charge what the work is actually worth.',
    },

    deliverables: [
      {
        title: 'Brand Discovery',
        desc: 'Before anything is drawn we work out what the identity has to fix. Your market, the three competitors you genuinely lose to, and the **gap between what you deliver and what people assume**.',
        points: [
          'Positioning, audience and competitor review',
          'Audit of every existing asset still in circulation',
          'Written creative direction agreed before design begins',
        ],
        image: '/images/services/branding/01-discovery.webp',
      },
      {
        title: 'Logo System',
        desc: 'One primary mark, plus the versions real life demands — horizontal, stacked, monogram, single colour. Drawn in vector from the first line, so it is **as sharp on a hoarding as on a favicon**.',
        points: [
          'Primary mark with horizontal and stacked lockups',
          'Monogram and app-icon version for small spaces',
          'Black, white and single-colour variants for print',
        ],
        image: '/images/services/branding/02-logo.webp',
      },
      {
        title: 'Colour & Type',
        desc: 'The palette and typefaces that carry the brand when the logo is nowhere on screen. Every colour is specified for **screen, print and fabric separately**, because those three never match by accident.',
        points: [
          'HEX, RGB, CMYK and Pantone values for every colour',
          'Display and body typefaces with licensing checked',
          'Heading, body and caption hierarchy defined',
        ],
        image: '/images/services/branding/03-colour-type.webp',
      },
      {
        title: 'Brand Guidelines',
        desc: 'The document that keeps the identity intact after we leave. Clear space, minimum sizes, correct and incorrect usage — written so **a printer can follow it without ringing anyone**.',
        points: [
          'Clear space, minimum size and placement rules',
          'Do and do-not examples drawn from real misuse',
          'Colour, type and imagery direction in one PDF',
        ],
        image: '/images/services/branding/04-guidelines.webp',
      },
      {
        title: 'Brand Applications',
        desc: 'The identity applied to the things customers actually hold and see. Visiting card, letterhead, bill format, signage, vehicle branding and social profiles — designed as **one set, not six separate jobs**.',
        points: [
          'Visiting card, letterhead and invoice format',
          'Signage, standee and vehicle branding artwork',
          'Social profile images, covers and post framework',
        ],
        image: '/images/services/branding/05-applications.webp',
      },
      {
        title: 'Files & Handover',
        desc: 'Everything organised into folders a non-designer can navigate. Print, web and office formats, plus the editable source files — **yours outright, with no retainer required to open them**.',
        points: [
          'AI, EPS, SVG, PDF, PNG and JPG for every variant',
          'Folders split by print, digital and office use',
          'Recorded walkthrough of the guidelines and files',
        ],
        image: '/images/services/branding/06-handover.webp',
      },
    ],

    /* Plain list kept for the home page and structured data. */
    tech: ['Adobe Illustrator', 'Adobe Photoshop', 'Figma', 'InDesign'],

    techStack: [
      {
        name: 'Adobe Illustrator',
        role: 'Vector mark drawing',
        logo: '/images/tech/adobeillustrator.webp',
        points: [
          'Every mark is drawn as vector curves, so it scales from favicon to hoarding without a redraw',
          'The editable .ai source is handed to you, not kept as a reason to keep paying us',
        ],
      },
      {
        name: 'Adobe Photoshop',
        role: 'Imagery and mockups',
        logo: '/images/tech/adobephotoshop.webp',
        points: [
          'Photo treatment and retouching so brand imagery stays consistent across the whole set',
          'Realistic mockups of signage, cards and packaging so you approve before anything is printed',
        ],
      },
      {
        name: 'Figma',
        role: 'Digital application',
        logo: '/images/tech/figma.webp',
        points: [
          'Where the identity is tested as a live interface — buttons, headers, forms, mobile screens',
          'Shared review links, so you comment directly on the work instead of trading screenshots',
        ],
      },
      {
        name: 'InDesign',
        role: 'Guidelines and layout',
        logo: '/images/tech/indesign.webp',
        points: [
          'Builds the guidelines document and multi-page collateral on a proper typographic grid',
          'Exports press-ready PDFs with bleed, crop marks and CMYK handled correctly the first time',
        ],
      },
    ],

    local: {
      heading: 'Built in Visnagar, applied wherever you trade',
      body:
        'We are based in Visnagar and build identities for businesses in Ahmedabad, Mehsana, across North Gujarat and the rest of India. For branding, being close by earns its keep at the **printing and fabrication stage** — the colour proof, the sign vendor, the sample that comes back wrong. Everything else runs on calls, WhatsApp and shared files, at whatever pace your business actually moves.',
      points: [
        'Artwork prepared to the specifications your printer and sign vendor actually use',
        'Bilingual lockups where the brand has to work in Gujarati and English',
        'You talk to the people doing the design, not an account manager',
        'Source files, font licensing notes and full ownership handed over at the end',
      ],
      stat: { value: 'Visnagar', label: 'Based in North Gujarat, working nationwide' },
    },

    faqNote:
      'Branding is the easiest place to spend money on something that changes nothing. These are the questions worth asking first — including **whether you should be doing this at all right now**.',

    faqs: [
      {
        q: 'What is included in a brand identity project?',
        a: 'Discovery, a logo system, a colour and type system, a written guidelines document, application designs and a complete file handover. In practice that means one primary mark plus horizontal, stacked, monogram and single-colour versions; colours specified separately for screen, print and fabric; typefaces with licensing checked so you are not putting something on a signboard you have no right to use; and the visiting card, letterhead, bill format and social profiles that turn an identity into something usable on Monday morning. Scope is written down and agreed before we start, so nobody discovers a missing deliverable at handover.',
      },
      {
        q: 'How is this different from just buying a logo?',
        a: 'A logo is one file. An identity is the set of decisions that keeps every future file consistent — which colour, which typeface, how much space around the mark, what happens when it must print in one colour on a plastic board. Buy only a logo and within eight months there will be three versions of it in circulation, because your printer, your social media person and your nephew each made a judgement call while you were busy. That said, if you are a six-month-old business with no signage, no collateral and no staff, a well-drawn mark and a two-page rules sheet may genuinely be enough for now. We will tell you if that is your situation rather than sell you the full project.',
      },
      {
        q: 'Do you rebrand existing businesses?',
        a: 'Yes, and it is more careful work than starting from nothing. The first step is an audit of what you already own — recognition, a colour people associate with you, a shape they remember, a name customers say a particular way. Some of that represents years of spend and should not be thrown out because a new designer finds it dated. What usually follows is an evolution rather than a replacement: the equity stays, the execution gets fixed. A clean break is only right when the old identity is actively working against you — wrong industry signals, a legal conflict, or a business that no longer does what the name implies.',
      },
      {
        q: 'How many logo concepts will I see?',
        a: 'Two or three, and each is a different strategic argument rather than a different decoration. Studios that present fifteen options are usually presenting one they believe in and fourteen to make it look chosen. That approach moves the decision from strategy to taste, and taste is where branding projects go to die — especially once three family members are in the room. Each concept is shown in context: on a board, on a card, on a phone screen, in one colour. Then two rounds of refinement on the direction you pick.',
      },
      {
        q: 'What file formats do I receive?',
        a: 'Vector source in AI and EPS, SVG for web and app use, layered PDF, plus PNG with transparency and JPG at several sizes for people who simply need to drop the mark into a document. Each of those exists for every variant — primary, horizontal, stacked, monogram — in full colour, all black, all white and single colour. Files arrive in folders labelled by use rather than by format, so your printer takes the print folder and your office staff take the office folder without needing to know what an EPS is. The editable sources are included. Some studios hold those back so you have to come back to them; we hand them over.',
      },
      {
        q: 'Do I own the copyright to the logo?',
        a: 'Yes. On final payment, ownership of the final artwork transfers to you in writing — you may use it, modify it, apply for a trademark and hand it to any other designer without asking us. Two honest limits. Typefaces are licensed, never owned: we specify fonts you can legally use and flag which ones need a purchase for signage or web embedding, but the foundry still owns the typeface. And we cannot guarantee trademark registrability — we check for obvious conflicts in your category, though a proper search is a lawyer’s job and worth paying for before the mark goes onto a hundred signboards.',
      },
      {
        q: 'What if I do not like any of the concepts?',
        a: 'It happens, and it usually means discovery missed something rather than that the drawing is bad — often the words you used to describe the business meant something different to you than to us. So we go back to the brief, find where it diverged, and you get a further round of directions at no extra cost. If a second full presentation still lands nowhere, we would rather stop and refund the balance of the unstarted stages than push through a mark you will quietly resent every time you see it on your board. We will also say plainly if the real problem is that four people hold an opinion and none of them holds the decision.',
      },
      {
        q: 'Is a rebrand the right spend for my business right now?',
        a: 'Often it is not, so answer this first: is the problem that people do not know you, or that they know you and choose somebody else? If nobody knows you exist, a new logo will not fix it — that money does more work in a website, a Google Business Profile and proper photographs of your actual work. If enquiries are arriving and dying at the quotation stage, or you are being pushed on price by people whose work is worse than yours, then the identity is a live commercial problem and worth fixing now. A rebrand also earns its cost when the business has genuinely changed: new services, a different customer, a name that no longer describes what you do. And if cash is tight, stage it — the logo system and the rules first, applications later. Spending ₹1.5 lakh on brand collateral while your website loses enquiries every week is the wrong order, and we will say so before taking the project.',
      },
    ],

    related: ['print', 'social', 'web-dev'],
  },

  /* ─────────────────────────────────────────────────────── */
  {
    id: 'social',
    slug: 'social-media-design',
    category: 'SOCIAL',
    icon: '◎',
    title: 'Social Media Design',
    shortTitle: 'Social Media Design',
    tagline: 'Consistent communication across platforms.',
    description:
      'Professional social media creatives designed to strengthen brand presence, maintain consistency, and help businesses communicate effectively with their audience.',
    image: '/images/services/social.webp',
    layout: 'right',
    features: ['Social Media Posts', 'Campaign Creatives', 'Content Visuals', 'Brand Communication', 'Promotional Designs'],

    /* ── Imagery ──────────────────────────────────────────
       Every slot is a real file path. Replacing the artwork is
       dropping a new .webp over the same filename — no code
       change, no import to update, nothing to rebuild by hand.
       See docs/image-brief.md for the prompt behind each one.
    ───────────────────────────────────────────────────── */
    media: {
      hero: '/images/services/social/hero.webp',
      problem: '/images/services/social/problem.webp',
      approach: '/images/services/social/approach.webp',
      local: '/images/services/social/local.webp',
      faq: '/images/services/social/faq.webp',
    },

    /* ── Page-level content ── */
    metaTitle: 'Social Media Design & Content Creatives in Gujarat — Manhar Creatives',
    metaDescription:
      'Professional social media design for Instagram, Facebook and LinkedIn. Branded post templates, campaign creatives and content systems that keep your business consistent and recognisable online.',
    keywords: [
      'social media design',
      'instagram post design',
      'social media creatives',
      'social media branding',
      'campaign design',
      'content design services',
      'social media templates',
      'facebook ad creatives',
    ],

    hero: {
      title: 'Social media design and post templates',
      accent: 'so the feed finally looks like one company',
      subtitle:
        'A customer opens your page before they ask your price, and what they are really doing is **counting how seriously you take your own business**. A feed stitched together from five different templates answers that badly. We build the visual direction, the editable templates and the finished creatives — **design only, not posting, captions or ad buying**.',
    },

    heroStats: [
      { value: '2–3', label: 'Weeks from direction to first batch of creatives' },
      { value: '12+', label: 'Editable templates in a standard kit' },
      { value: '6', label: 'Formats covered across feed, story and reel' },
    ],

    problem: {
      heading: 'You post every week, and it has never once brought you a customer',
      body: [
        'Look at your last nine posts together, the way a stranger does. A festival greeting in one font, an offer in another, a photo somebody forwarded on WhatsApp, a quote card from a free app. Each one was fine on the day it went out. As a grid they read like **five different businesses sharing one account**, and the person deciding whether to call you is reading the grid, not the caption.',
        'Meanwhile the likes arrive from staff, family and the same twelve people every week, which feels like progress and is not. The competitor whose work you know is weaker posts half as often — but every post of theirs is recognisable at a glance, so it stacks up. Yours **starts from zero every time**, which is why an account three years old can still feel like it opened last month.',
      ],
      points: [
        'Nine recent posts, **five different fonts** — the grid reads as five different businesses',
        'Designs made in Canva by **whoever was free that week**, with no rules to follow',
        'Likes from friends and staff, and **not one enquiry** you can trace back to a post',
        'Text sized for a laptop, so in the feed on a phone it is **unreadable at thumb speed**',
        'A competitor who is **worse at the actual work** looks more professional in the grid',
      ],
    },

    solution: {
      heading: 'Recognition is not built by posting more. It is built by posting the same way.',
      body: [
        'So this is not a pile of pretty pictures delivered by the dozen. It is a short set of decisions made once — where the headline sits, which two colours carry an offer, how a photo is cropped, what a testimonial looks like — and then applied without re-arguing them every week. Once those are fixed a post takes **twenty minutes instead of an afternoon**, and it comes out looking like you whoever makes it.',
        'What we are direct about is the boundary. We design the system and the creatives. We do not run your accounts, write daily captions, reply to comments or buy ads — that work needs somebody inside your business who knows the customers and can answer a price question within the hour. Hire that person or do it yourself. **You will get better results and pay less** than putting a design studio on a management retainer.',
      ],
      pillars: [
        {
          title: 'Direction before decoration',
          desc: 'Grid rhythm, type scale, colour roles and photo treatment agreed on paper before a single post is designed. Skip this stage and you are simply making nice pictures at random.',
        },
        {
          title: 'Templates, not one-offs',
          desc: 'Everything is built as an editable template with the rules locked in, so the next fifty posts stay consistent whether we produce them or your team does at nine on a Monday.',
        },
        {
          title: 'Judged at phone size',
          desc: 'Every layout is checked the way it will actually be seen — scrolled past on a mid-range Android, not admired full screen on a designer’s monitor.',
        },
      ],
      quote:
        'We design, we build, you grow — and on social, growth starts the day a stranger recognises your post before they read the name on it.',
    },

    deliverables: [
      {
        title: 'Visual Direction',
        desc: 'Before anything is designed we settle how the feed should behave as a whole — grid rhythm, type scale, colour roles, photo treatment. This is the stage that stops the account turning back into **a folder of unrelated pictures** in six months.',
        points: [
          'Feed grid and format plan agreed before design starts',
          'Colour roles set for offers, tips, announcements and festivals',
          'Photo and graphic treatment rules written down, not assumed',
        ],
        image: '/images/services/social/01-direction.webp',
      },
      {
        title: 'Template System',
        desc: 'The reusable engine of the whole service. Editable templates for the post types you genuinely publish, built with **locked layouts and open text fields** so nothing drifts when someone is in a hurry.',
        points: [
          'Twelve or more templates across announcement, offer, tip, testimonial and product',
          'Grids and logo placement locked, text and image slots editable',
          'Built in Figma or Canva — whichever your team can actually use',
        ],
        image: '/images/services/social/02-templates.webp',
      },
      {
        title: 'Post & Carousel Design',
        desc: 'A finished batch produced from the system, so you launch with a full grid instead of an empty one. Carousels are structured as **a sequence with a reason to swipe**, not five slides repeating the same claim.',
        points: [
          'Batch of finished feed posts in square and portrait',
          'Multi-slide carousels with hook, body and closing slide',
          'Exported at correct platform dimensions, source files included',
        ],
        image: '/images/services/social/03-posts.webp',
      },
      {
        title: 'Story & Reel Covers',
        desc: 'Stories and reels are where most brands abandon the design entirely. We build the story frames and the reel cover set so the profile stays **readable as a wall**, not a jumble of paused video stills.',
        points: [
          'Story templates for offers, polls, repost frames and behind-the-scenes',
          'Reel cover set that lines up as a consistent grid',
          'Safe areas checked so text never sits under platform icons',
        ],
        image: '/images/services/social/04-stories.webp',
      },
      {
        title: 'Profile & Highlights',
        desc: 'The part a first-time visitor sees before a single post. Profile image, highlight covers and bio structure designed together, because that top section is **the shopfront of the account**.',
        points: [
          'Profile image cropped and tested at circular thumbnail size',
          'Highlight cover set with a clear labelling structure',
          'Bio layout, link ordering and pinned-post plan',
        ],
        image: '/images/services/social/05-profile.webp',
      },
      {
        title: 'Handover Kit',
        desc: 'Everything handed over in a form your team can reuse without calling us first. Templates, fonts, exports and a short usage sheet — **yours to keep, editable without us in the loop**.',
        points: [
          'Editable Figma or Canva files transferred to your own account',
          'One-page usage sheet: what to change, what never to change',
          'Recorded walkthrough of editing and exporting a post',
        ],
        image: '/images/services/social/06-handover.webp',
      },
    ],

    /* Plain list kept for the home page and structured data. */
    tech: ['Figma', 'Adobe Photoshop', 'Adobe Illustrator', 'After Effects'],

    techStack: [
      {
        name: 'Figma',
        role: 'Template building',
        logo: '/images/tech/figma.webp',
        points: [
          'Where the template system is assembled — components and locked grids, so a text change never breaks a layout',
          'Exports every size in one pass, so the same design ships for feed, story and reel cover',
        ],
      },
      {
        name: 'Adobe Photoshop',
        role: 'Image work',
        logo: '/images/tech/adobephotoshop.webp',
        points: [
          'Cleans up the shop, product and team photos you already have, so posts do not wait on a shoot',
          'Same colour and crop treatment across the batch, so nine photos read as one feed',
        ],
      },
      {
        name: 'Adobe Illustrator',
        role: 'Graphics and icons',
        logo: '/images/tech/adobeillustrator.webp',
        points: [
          'Draws the icons, badges and offer devices that make a template recognisable as yours, not stock',
          'Vector artwork, so the same graphic moves from a story frame to a printed standee without redrawing',
        ],
      },
      {
        name: 'After Effects',
        role: 'Motion posts',
        logo: '/images/tech/aftereffects.webp',
        points: [
          'Animated versions of the static templates for reels, story frames and offer announcements',
          'Exported light enough to upload on shop wifi, before the platform crushes the quality',
        ],
      },
    ],

    local: {
      heading: 'Designed in Visnagar, posted from wherever you trade',
      body:
        'We are based in Visnagar and design for businesses in Ahmedabad, Mehsana, across North Gujarat and the rest of India. On social the local part earns its keep in one specific way — **the post has to read in Gujarati as well as English**, and a festival calendar drawn up somewhere else always misses the days that actually matter to your customers. Everything else runs on calls, WhatsApp and shared files.',
      points: [
        'Bilingual layouts where the post must work in Gujarati and English',
        'Festival and seasonal creatives planned around the dates your customers keep',
        'You talk to the designer doing the work, not an account manager',
        'Templates and source files transferred into your own account at handover',
      ],
      stat: { value: 'Visnagar', label: 'Based in North Gujarat, designing for clients nationwide' },
    },

    faqNote:
      'Social media is the easiest service in this list to oversell, so these answers include the parts most studios leave out — including **when this is not the thing to spend on yet**.',

    faqs: [
      {
        q: 'Do you also manage the social media accounts?',
        a: 'No, and we would rather say it plainly than take a retainer we cannot service properly. We design the system and the creatives — direction, templates, finished posts, story frames, profile assets. Posting on schedule, writing daily captions, replying to comments and DMs within the hour, and running paid campaigns is a different job that needs somebody inside your business who knows the customers and can answer a price question at nine at night. That is a staff member, a trained intern, or a dedicated social manager, and any of the three will beat a design studio pretending to do it between projects. What we do hand over is the template set, a usage sheet and a suggested content structure, so whoever posts is never starting at a blank screen. If you need a manager, ask us what to look for and what a fair monthly rate is — we will tell you without taking a cut.',
      },
      {
        q: 'Can you match our existing brand?',
        a: 'Yes, and that is the easier version of this project. Where brand guidelines exist we work strictly inside them — palette, typefaces, logo lockups, clear space — so the feed becomes an extension of the identity instead of a second look competing with it. Where they do not exist, which is more common, we define the minimum needed for the feed to hold together: two or three colour roles, a heading and body typeface, a logo placement rule and a grid. That is not a full brand identity project and we will not price it like one. Be clear on what it means, though — the feed will be consistent with itself while your signboard, bill book and website may still disagree with each other. If that gap is wide, fixing the identity first is the better order and we will say so.',
      },
      {
        q: 'What formats do you deliver?',
        a: 'Square and portrait feed posts, multi-slide carousels, story frames, reel covers, profile images and highlight covers — each exported at the correct pixel dimensions for Instagram, Facebook and LinkedIn rather than one size stretched across all three. Editable source files come with it, in Figma or Canva depending on what your team can realistically operate. Text is positioned inside platform safe areas, so nothing important disappears under the username, the caption fold or a story reply box. Where a design needs a motion version, that is delivered as MP4 at a file size that will actually upload on a shop connection instead of failing three times.',
      },
      {
        q: 'Can we edit the templates ourselves afterwards?',
        a: 'Yes — that is the entire point of building templates rather than delivering flat images. Layouts, grids and logo positions are locked; text, photos, prices and offer details are open. Someone with no design background can change a price, drop in a product photo and export a post in about ten minutes, and it will still sit correctly beside the rest of the feed. The files go into your own Figma or Canva account, not ours, so access never depends on our relationship continuing. You also get a recorded walkthrough and a one-page sheet covering what to change and what to leave alone. The honest limit: templates hold a brand together for routine posting, not for a campaign that needs a genuinely new idea. When that comes up, commission a fresh set rather than forcing an old template to carry it.',
      },
      {
        q: 'How many designs come in one batch?',
        a: 'A standard kit is twelve or more templates plus a launch batch of finished posts, and the exact split is written into the scope before we start rather than left vague. In practice most businesses need fewer template types than they expect — announcement, offer, tip or educational, testimonial, product or menu highlight, and a festival frame will cover the large majority of what a small business posts in a year. Ongoing batches, if you want them, are monthly sets of finished creatives built from the existing system, which costs less than the first batch because the thinking is already done. We would rather deliver fifteen posts you actually publish than forty you never open. And if your team can comfortably produce three good posts a week from the templates alone, say so — we will scope the system only and skip the batch.',
      },
      {
        q: 'What do you need from us to start?',
        a: 'Less than most people assume, but the pieces we ask for matter. Your logo in the best format you hold — vector if it exists, and if it does not we will tell you honestly whether it survives at social sizes or needs redrawing first. Real photographs of your work, your premises, your product or your team, even shot on a phone, because stock imagery is the fastest way to look like every other account in your category. A short list of what you sell and what you want a viewer to do next. And one person who can approve designs: three people with opinions and no decision-maker is what turns a two-week project into a two-month one. If photography is the real gap, we will flag it early — sometimes the right first spend is a half-day shoot, not a design system.',
      },
      {
        q: 'Do we actually need social media design yet?',
        a: 'Sometimes not, and it is worth testing that before you spend. If you cannot say in one sentence what you sell, who it is for and why someone should choose you over the shop two streets away, a polished feed will only make that confusion look more expensive. Fix the offer first — it costs nothing and changes everything downstream. If the problem is that nobody knows you exist, a properly built Google Business Profile with real photographs and reviews will usually bring more enquiries this quarter than an Instagram grid will, because that is where people look when they are ready to buy. And if your website is losing enquiries every week, the ₹25,000 does more work there than on post templates. Social design earns its cost when three things are already true: the offer is clear, there is real work worth showing, and somebody will post consistently. Without that third one especially, you are buying templates nobody opens.',
      },
    ],

    related: ['branding', 'print', 'digital-presence'],
  },

  /* ─────────────────────────────────────────────────────── */
  {
    id: 'print',
    slug: 'print-branding',
    category: 'PRINT',
    icon: '◆',
    title: 'Print & Offline Branding',
    shortTitle: 'Print & Offline Branding',
    tagline: 'Professional branding beyond the screen.',
    description:
      'High-quality print and offline branding materials designed to reinforce your brand identity and create a consistent experience across every customer touchpoint.',
    image: '/images/services/print.webp',
    layout: 'left',
    features: ['Business Cards', 'Brochures', 'Flyers', 'Signage', 'Marketing Materials'],

    /* ── Imagery ──────────────────────────────────────────
       Every slot is a real file path. Replacing the artwork is
       dropping a new .webp over the same filename — no code
       change, no import to update, nothing to rebuild by hand.
       See docs/image-brief.md for the prompt behind each one.
    ───────────────────────────────────────────────────── */
    media: {
      hero: '/images/services/print/hero.webp',
      problem: '/images/services/print/problem.webp',
      approach: '/images/services/print/approach.webp',
      local: '/images/services/print/local.webp',
      faq: '/images/services/print/faq.webp',
    },

    /* ── Page-level content ── */
    metaTitle: 'Print Design & Offline Branding in Gujarat | Brochures, Signage — Manhar Creatives',
    metaDescription:
      'Print-ready brochure design, business cards, flyers, signage, packaging and marketing materials for businesses in Gujarat. Consistent offline branding that matches your digital presence.',
    keywords: [
      'print design services',
      'brochure design',
      'business card design',
      'flyer design',
      'signage design',
      'packaging design',
      'catalogue design',
      'offline branding',
      'marketing collateral design',
    ],

    hero: {
      title: 'Print design and offline branding',
      accent: 'where the buying decision actually happens',
      subtitle:
        'The card that crosses a table, the board a customer walks past for years, the brochure left behind after the meeting — print is the part of your brand a person **physically holds in their hand**. It is also the part that punishes carelessness: one wrong colour profile, one bleed trimmed badly, and you have paid for **five thousand copies of the mistake**. We design the piece and prepare the file, so what comes off the press is what you approved on screen.',
    },

    heroStats: [
      { value: '1–3', label: 'Weeks from brief to press-ready artwork' },
      { value: '300 DPI', label: 'CMYK minimum on every file that goes to press' },
      { value: '3 mm', label: 'Bleed on all four edges, with crop marks' },
    ],

    problem: {
      heading: 'The card in their pocket is undoing what your website did',
      body: [
        'The meeting went well. On the way out you handed over a card, and the other person did what everybody does — held it for a second, then put it away. Thin stock. The logo pulled slightly wide because somebody resized it without holding the corner. A phone number set in whatever font happened to be open. Nothing was said, and nothing needed to be. Three weeks later that card comes out of a drawer beside a competitor’s, and **it loses the comparison in silence**.',
        'Signage is worse, because it lasts. The board above your shop was laid out in ten minutes by whoever was free at the printer’s machine, because ₹3,000 of design looked like a cost worth avoiding. Every person who walks that street will read it for the next six years. The red came back orange, the logo was redrawn by eye, and when the file turned out to be a low-resolution JPG, the reprint was **billed to you, not to them**.',
      ],
      points: [
        'A visiting card that feels **flimsy the moment it is picked up**',
        'Signage laid out by the **printer’s operator in ten minutes**, with nobody checking',
        'A logo **stretched out of shape** on a banner that is now up for two years',
        'Colours that looked right on screen and came back from the press **a different colour entirely**',
        'A file rejected or misprinted, so you pay **twice for the same five thousand pieces**',
      ],
    },

    solution: {
      heading: 'Print is specified before it is designed — that order is the whole job',
      body: [
        'Every printed piece is judged twice: once on a screen when you approve it, and once in the hand when the delivery arrives. Those two only agree when the unglamorous work happens first — final trim size, paper weight and finish, the press it will run on, colour mode, resolution at actual size, bleed, and the quantity that makes the unit rate sensible. Settle that at the start and the design has something real to sit on. Skip it and you are **designing for a screen and hoping the press agrees**.',
        'So we design the piece and prepare the file that produces it, working from the same colour and type rules your website already uses, so the two stop looking like different companies. We will also tell you when you are buying too much. Plenty of businesses order five thousand flyers because the per-piece rate looked better, hand out four hundred, then bin the rest when a number changes — **the cheaper unit price was the more expensive decision**.',
      ],
      pillars: [
        {
          title: 'Specified, then designed',
          desc: 'Trim size, paper, finish, press, colour mode and quantity agreed before layout begins. A design made without knowing what it will be printed on is a guess with your money attached to it.',
        },
        {
          title: 'Built for the machine',
          desc: 'CMYK, bleed on all four edges, crop marks, outlined type, correct resolution at final size, and dielines matched to the fabricator’s template — so the file runs the first time it is opened.',
        },
        {
          title: 'One brand on every surface',
          desc: 'Card, board, brochure, label and website drawing on the same colour values, typefaces and spacing, so a customer who meets you offline recognises you online.',
        },
      ],
      quote:
        'We design, we build, you grow — and in print, growth starts when the thing in a customer’s hand stops arguing with the price on your quotation.',
    },

    deliverables: [
      {
        title: 'Stationery System',
        desc: 'Visiting cards, letterheads, envelopes, bill books and invoice formats designed as **one coordinated set** — not five separate jobs ordered whenever something runs out.',
        points: [
          'Visiting card with paper weight and finish specified, not left to the printer',
          'Letterhead and envelope built to standard sizes and postal margins',
          'Bill book and invoice format your accounts staff can actually use',
        ],
        image: '/images/services/print/01-stationery.webp',
      },
      {
        title: 'Brochures & Profiles',
        desc: 'Company profiles, product catalogues and multi-page brochures built on a **proper typographic grid**, so a reader finds what they came for instead of admiring the cover.',
        points: [
          'Page flow planned around the order a buyer asks questions in',
          'Consistent grid, type hierarchy and image treatment across every spread',
          'Page count and imposition checked against the binding method',
        ],
        image: '/images/services/print/02-brochures.webp',
      },
      {
        title: 'Signage & Outdoor',
        desc: 'Storefront boards, flex banners, standees and hoardings drawn for **the distance they will be read from** — not designed on a laptop and scaled up afterwards.',
        points: [
          'Artwork built at correct scale, legibility checked at real viewing distance',
          'Files supplied in the format your flex, acrylic or LED vendor runs',
          'Colour specified separately for vinyl, backlit and painted output',
        ],
        image: '/images/services/print/03-signage.webp',
      },
      {
        title: 'Packaging & Labels',
        desc: 'Product cartons, pouches, sleeves and labels built to the **converter’s own dieline**, with the statutory panels laid out to the sizes the rules require.',
        points: [
          'Dieline taken from your converter and matched exactly, on its own layer',
          'Ingredient, net weight, MRP and licence panels placed to requirement',
          'Physical mockup approved before any plate, block or cylinder is made',
        ],
        image: '/images/services/print/04-packaging.webp',
      },
      {
        title: 'Print-Ready Artwork',
        desc: 'The stage nobody sees, which decides whether the job runs. Files are packaged so **a printer opens them and goes straight to plate**, with nothing to interpret and nothing to ring you about.',
        points: [
          'PDF/X export in CMYK with 3 mm bleed and crop marks',
          'Type outlined or embedded, images linked at 300 DPI at final size',
          'Packaged folder with source file, links and a written specification sheet',
        ],
        image: '/images/services/print/05-artwork.webp',
      },
      {
        title: 'Press Coordination',
        desc: 'We can deal with the printer for you — quotes compared, proof checked, first sheets seen. Or you take the files and place the order yourself, which is often **cheaper and completely fine**.',
        points: [
          'Quotes compared on stock, finish and quantity rather than headline rate',
          'Physical or digital proof reviewed and signed off before the full run',
          'Press check attended on jobs where the colour has to be exact',
        ],
        image: '/images/services/print/06-press.webp',
      },
    ],

    /* Plain list kept for the home page and structured data. */
    tech: ['Adobe InDesign', 'Adobe Illustrator', 'Adobe Photoshop', 'CorelDRAW'],

    techStack: [
      {
        name: 'Adobe InDesign',
        role: 'Multi-page layout',
        logo: '/images/tech/adobeindesign.webp',
        points: [
          'Brochures, catalogues and profiles built on a master grid, so page forty still matches page four',
          'Exports PDF/X with bleed, crop marks and CMYK handled at export rather than patched afterwards',
        ],
      },
      {
        name: 'Adobe Illustrator',
        role: 'Vector and dielines',
        logo: '/images/tech/adobeillustrator.webp',
        points: [
          'Logos, signage and label artwork drawn as vector, so a board scales up without a redraw',
          'Dielines and cutting paths built to the converter’s template and supplied on a separate layer',
        ],
      },
      {
        name: 'Adobe Photoshop',
        role: 'Image preparation',
        logo: '/images/tech/adobephotoshop.webp',
        points: [
          'Product and premises photographs corrected, resized and sharpened for CMYK, not for a screen',
          'Realistic mockups of the card, board or pack so you approve it before money reaches the press',
        ],
      },
      {
        name: 'CorelDRAW',
        role: 'Local press files',
        logo: '/images/tech/coreldraw.webp',
        points: [
          'Most flex, sign and screen-print shops in Gujarat run Corel, so we supply CDR when that is what they need',
          'Removes the redraw-by-eye step that quietly changes your logo at the vendor’s end',
        ],
      },
    ],

    local: {
      heading: 'Near the press, which is where print is won or lost',
      body:
        'We are based in Visnagar and work with businesses in Ahmedabad, Mehsana, across North Gujarat and the rest of India. For print, being nearby is not a courtesy — it is **the difference between approving a colour on a screen and approving it on the paper it will be printed on**. When the job justifies it we handle stock by hand, check the proof under real light and stand at the machine for the first sheets. For clients further away, the files and a written specification go out, and any competent printer can follow them.',
      points: [
        'Paper, board and finish selected by hand rather than from a dropdown',
        'Proof approval and press checks in person on jobs where colour has to be exact',
        'Artwork prepared in the formats local printers and flex shops actually run, CorelDRAW included',
        'Bilingual layouts where the card, board or label must read in Gujarati and English',
      ],
      stat: { value: 'Visnagar', label: 'Based in North Gujarat, printing coordinated nationwide' },
    },

    faqNote:
      'Print is the one service here where the honest answer usually saves you money, so several of these will talk you **out of spending rather than into it**.',

    faqs: [
      {
        q: 'Do you handle the actual printing?',
        a: 'We design the piece and supply production-ready artwork. Printing itself we coordinate rather than own — we do not run a press, and a studio that quietly adds a margin on top of a printer you could have rung directly is charging you for a phone call. For clients in and around Visnagar, Mehsana and Ahmedabad we will gather quotes, compare them properly on stock and finish rather than headline rate, check the proof and attend the press for the first sheets when the colour has to be exact. For everyone else, and for anyone who already has a printer they trust, we hand over the files plus a written specification sheet and you place the order yourself. That usually costs less and keeps the turnaround under your control instead of ours.',
      },
      {
        q: 'What files will I receive?',
        a: 'A press-ready PDF/X in CMYK with 3 mm bleed and crop marks — the file a printer actually needs — plus the packaged source: INDD or AI with every link and font collected, or CDR where the vendor runs Corel. Images are linked at 300 DPI at final printed size, type is outlined or embedded, and dielines sit on their own layer. Alongside that comes a one-page specification sheet listing trim size, paper stock and weight, finish, colour mode, ink coverage and quantity. Hand the PDF and that sheet to any printer in the country and there is nothing left for them to interpret. You also get low-resolution PDFs and JPGs for internal approval, so nobody has to email a 200 MB file to a director just to get a yes.',
      },
      {
        q: 'Can I take the files to my own printer?',
        a: 'Yes, and we would rather you did if you already have someone reliable. The files are yours on final payment — no watermark, no locked layers, no version that only opens while you keep paying us. A printer you have used for years, who knows your paper and remembers what went wrong last time, is worth more than a cheaper quote from a stranger. If your printer comes back asking for a different format, a different colour profile or a CDR instead of a PDF, forward the request and we will supply it without charging for it. The single thing we will not do is guarantee the output of a press we have never seen. If you want that guarantee, bring us in at the proofing stage.',
      },
      {
        q: 'How do you make sure the printed colour matches what I approved on screen?',
        a: 'Partly by process, partly by being honest about the limit. Your monitor makes colour out of light; the press makes it out of ink sitting on absorbent paper. The two can be brought close, never made identical, and anyone promising an exact match has not printed much. What we do control: design in CMYK from the first file instead of converting from RGB at the end, specify brand colours with Pantone references where the budget allows a spot colour, and account for the stock, because the same ink reads noticeably duller on uncoated paper than on coated. For anything critical — packaging, a signboard, a company profile — we ask for a physical proof on the actual stock before the full run is released. A proof costs ₹500 or so. Reprinting five thousand cartons does not.',
      },
      {
        q: 'What do you need from me to start?',
        a: 'Four things, and you probably have three of them. Your logo in vector — AI, EPS, SVG or PDF, not a JPG pulled off your own website. If no vector exists, say so early: we either redraw it or tell you the identity itself is the job that should come first. Final text, checked and approved by whoever has the authority to change it, because a correction after plates are made is a reprint rather than an edit. Photographs at full resolution, straight from the camera or phone, not the compressed copies that have been through WhatsApp. And for packaging or labels, the dieline from your converter along with any statutory content — ingredients, net weight, MRP, licence numbers. We lay that information out correctly and at the required sizes, but verifying what it says is yours, because yours is the name on the declaration.',
      },
      {
        q: 'Can you match my printed materials to my website?',
        a: 'Yes, and it is the main reason to have one studio do both. We work from a single brand system: the same typefaces, the same colour values converted deliberately for print rather than eyeballed, the same spacing logic and the same tone of writing. In practice that means the CMYK build of your brand colour is chosen to sit as close to the HEX value on your site as the process allows, and the print typeface is either the same family or a companion licensed for print use. One thing worth knowing before you spend, though: printing a consistent set of material for an identity that was never defined only multiplies the inconsistency across more surfaces. If that is your situation, the money does more work on the identity and its rules first, and the printing second.',
      },
      {
        q: 'How much should I actually print?',
        a: 'Almost certainly less than the quantity you are about to order. The per-piece rate falls as the run grows, which is true, and it is also how businesses end up with four boxes of dead flyers in a storeroom after the office moved or a number changed. Work backwards from distribution instead: how many will genuinely be handed to a human being in the next six months, and by whom. Visiting cards at 500 per person usually cover a year comfortably. For a company profile, a short digital run of 50 to 100 beats 1,000 offset copies you will want to revise after the first ten meetings. Flyers are worth printing in the quantity you have an actual plan to distribute, not the quantity that made the quote look efficient. Then spend the difference on better paper — a heavier card with a decent finish adds perhaps ₹2 a piece, and it is the part the customer physically notices.',
      },
    ],

    related: ['branding', 'social', 'digital-presence'],
  },

  /* ─────────────────────────────────────────────────────── */
  {
    id: 'digital-presence',
    slug: 'digital-presence',
    category: 'DIGITAL PRESENCE',
    icon: '⟐',
    title: 'Digital Presence Setup',
    shortTitle: 'Digital Presence Setup',
    tagline: 'Build a stronger online presence.',
    description:
      'Essential digital setup services that help businesses present a professional image online, improve discoverability, and maintain consistency across key digital platforms.',
    image: '/images/services/digital-presence.webp',
    layout: 'right',
    features: ['Google Business Profile', 'Business Email Setup', 'WhatsApp Business', 'Online Presence Setup', 'Digital Optimization'],

    /* ── Imagery ──────────────────────────────────────────
       Every slot is a real file path. Replacing the artwork is
       dropping a new .webp over the same filename — no code
       change, no import to update, nothing to rebuild by hand.
       See docs/image-brief.md for the prompt behind each one.
    ───────────────────────────────────────────────────── */
    media: {
      hero: '/images/services/digital-presence/hero.webp',
      problem: '/images/services/digital-presence/problem.webp',
      approach: '/images/services/digital-presence/approach.webp',
      local: '/images/services/digital-presence/local.webp',
      faq: '/images/services/digital-presence/faq.webp',
    },

    /* ── Page-level content ── */
    metaTitle: 'Google Business Profile & Local SEO Setup in Gujarat — Manhar Creatives',
    metaDescription:
      'Google Business Profile setup and optimisation, business email, WhatsApp Business and local SEO foundations so customers can find, verify and contact your business instantly.',
    keywords: [
      'google business profile setup',
      'google my business optimization',
      'local seo services',
      'google maps listing',
      'business email setup',
      'whatsapp business setup',
      'online presence setup',
      'local business seo',
    ],

    hero: {
      title: 'Google Business Profile and local search setup',
      accent: 'because the customer is already searching',
      subtitle:
        'Right now someone two kilometres from your door is typing your service and the words “near me” into a phone, and they will call one of the three businesses Google puts in front of them. If your listing is unclaimed, half-filled or still showing hours from two years ago, **you are not one of those three**. We claim it, fill it in properly and make your details agree everywhere they appear — unglamorous groundwork **most of your competitors have never finished**.',
    },

    heroStats: [
      { value: '1–2', label: 'Weeks to claim and build the profile out' },
      { value: '8+', label: 'Profiles and listings made to say the same thing' },
      { value: '76%', label: 'Of nearby phone searches end in a visit within a day' },
    ],

    problem: {
      heading: 'They were looking for you specifically, and they still called somebody else',
      body: [
        'A customer heard your name over lunch. By evening they have half-forgotten it, so they search the service instead of the name, and what loads is a map with three businesses on it. Yours is on there, technically. No photos, a phone number you stopped using two years ago, hours that say closed on a day you are open. **They do not ring to check.** They tap the listing above yours, which has twenty photos and forty reviews, and the enquiry is gone before you knew it existed.',
        'Most of this was never a competitive contest. Google builds that map from what it can verify — categories, services, hours, photos, reviews, a working website link, details that match across the web. The business sitting above you is often not better run than yours. It simply **filled in the fields you left blank**, once, in an afternoon, three years ago. And because a listing that never appeared generates no missed call, nothing in your records will ever tell you it happened.',
      ],
      points: [
        'A listing you have **never once logged into** — claimed by an old agency, or never claimed at all',
        'Hours, phone number or address that are **wrong on the map** and correct nowhere else',
        'Not a single photo, so customers see **a grey Street View shot** of somebody else’s shutter',
        'A competitor with **eleven reviews ranking above you** because their fields are filled and yours are not',
        'Enquiries you never lost on price — you lost them **before the conversation started**',
      ],
    },

    solution: {
      heading: 'The cheapest ground in local search is still sitting there unclaimed',
      body: [
        'Treat the profile the way you would treat a page on your website, because that is what it is — for many buyers it is the only page they will ever read. Categories decide which searches you are eligible for at all. The services list, hours, attributes and description decide whether you look like a real operation. Photos are the proof. Reviews are the tiebreaker between two businesses that look otherwise identical. **Every one of those is a field somebody has to sit down and complete**, and that is the entire job.',
        'Where we will talk you out of spending: this is largely a one-time correction, not a monthly retainer. Once the profile is built, verified and in your own Google account, keeping it right is a few minutes a week that your own staff can do — posting a photo, answering a review, changing hours before a festival. **Nobody should be billing you every month to do that.** We also cannot move your pin. Proximity is a ranking factor and a customer three towns away may still see the shop nearest them, whatever we optimise.',
      ],
      pillars: [
        {
          title: 'Claimed, not just created',
          desc: 'Ownership verified and transferred into your own Google account — including recovering a listing an old agency or a former employee is still holding. If you cannot log in yourself, you do not own it.',
        },
        {
          title: 'Every field completed',
          desc: 'Categories, services, attributes, hours, service areas, description and links filled in deliberately, because on a map listing the fields are the ranking signals. Blank space is not neutral. It costs position.',
        },
        {
          title: 'Proof over polish',
          desc: 'Real photographs of your premises, your team and your work, plus a review routine you can actually keep. A profile has to survive a stranger checking whether the business is genuine.',
        },
      ],
      quote:
        'We design, we build, you grow — and here, growth starts with the plainest thing of all: being the business that appears when someone is already looking for one.',
    },

    deliverables: [
      {
        title: 'Audit & Claim',
        desc: 'We find everything that already exists under your name — the listing you forgot, the duplicate a customer created, the one an old agency still controls — and get **ownership into your account**, not ours.',
        points: [
          'Full sweep for existing, duplicate and unclaimed listings',
          'Ownership request or recovery where somebody else holds the profile',
          'Verification handled and tracked through to approval',
        ],
        image: '/images/services/digital-presence/01-audit.webp',
      },
      {
        title: 'Profile Build-Out',
        desc: 'The unglamorous part that decides everything. Primary and secondary categories, service list, description, hours, attributes and service areas completed properly — **categories chosen from what customers type**, not from what the trade calls it.',
        points: [
          'Primary and secondary categories researched against local search terms',
          'Services, description, attributes and service areas written and entered',
          'Regular, festival and special hours set so the map is never wrong',
        ],
        image: '/images/services/digital-presence/02-profile.webp',
      },
      {
        title: 'Photos & Proof',
        desc: 'Photographs are the first thing a customer judges and the field most businesses skip entirely. We curate, correct and order what you have — and tell you plainly when **a half-day of real photography** would do more than anything else on this list.',
        points: [
          'Logo, cover, exterior, interior, team and work photos prepared at correct sizes',
          'Existing phone photographs cleaned up rather than replaced with stock',
          'A simple shot list your team can keep adding to each month',
        ],
        image: '/images/services/digital-presence/03-photos.webp',
      },
      {
        title: 'Contact Channels',
        desc: 'The moment someone decides to contact you is the moment most businesses lose them. Domain email and WhatsApp Business configured so an enquiry **lands somewhere a person will actually see it**.',
        points: [
          'Business email on your own domain, replacing the personal Gmail address',
          'WhatsApp Business profile, catalogue, greeting, away and quick-reply messages',
          'Call, message and enquiry routing agreed so nothing sits unanswered',
        ],
        image: '/images/services/digital-presence/04-channels.webp',
      },
      {
        title: 'Review System',
        desc: 'A routine, not a campaign. A short link and QR code your staff can hand over at the right moment, plus response templates — because **an answered review reads better than a five-star one**.',
        points: [
          'Review request link and printable QR for counter, invoice or WhatsApp',
          'Response templates for positive, mixed and genuinely angry reviews',
          'A weekly ten-minute routine your team owns after handover',
        ],
        image: '/images/services/digital-presence/05-reviews.webp',
      },
      {
        title: 'Listings & Handover',
        desc: 'Name, address and phone made identical everywhere they appear, tracking connected so the profile stops being guesswork, and **the keys handed to you** — logins, ownership and a walkthrough.',
        points: [
          'NAP consistency corrected across directories, social profiles and your website',
          'Search Console, Analytics 4 and Tag Manager connected to measure calls and clicks',
          'Ownership transferred, credentials handed over, recorded walkthrough included',
        ],
        image: '/images/services/digital-presence/06-handover.webp',
      },
    ],

    /* Plain list kept for the home page and structured data. */
    tech: ['Google Business Profile', 'Google Search Console', 'Google Analytics 4', 'Google Tag Manager', 'WhatsApp Business'],

    techStack: [
      {
        name: 'Google Business Profile',
        role: 'Map presence',
        logo: '/images/tech/googlebusinessprofile.webp',
        points: [
          'Where the claiming, verification, categories, services, hours and photos are actually done',
          'Its own call, direction and message counts tell us which changes moved anything',
        ],
      },
      {
        name: 'Google Search Console',
        role: 'Search visibility',
        logo: '/images/tech/googlesearchconsole.webp',
        points: [
          'Shows the real queries bringing people to your site, including the ones you never targeted',
          'Flags indexing and mobile problems that quietly hold back the profile linked to it',
        ],
      },
      {
        name: 'Google Analytics 4',
        role: 'Visitor data',
        logo: '/images/tech/googleanalytics4.webp',
        points: [
          'Separates traffic arriving from the map listing from everything else, so the work is measurable',
          'Set up with your enquiry form and click-to-call marked as conversions from day one',
        ],
      },
      {
        name: 'Google Tag Manager',
        role: 'Event tracking',
        logo: '/images/tech/googletagmanager.webp',
        points: [
          'Tracks calls, WhatsApp taps and direction requests without a developer touching the site again',
          'Keeps every tag in one container you own, so nothing is buried in the theme',
        ],
      },
      {
        name: 'WhatsApp Business',
        role: 'Customer contact',
        logo: '/images/tech/whatsappbusiness.webp',
        points: [
          'Configured with catalogue, greeting and quick replies so common questions answer themselves',
          'Linked from the profile and the site, because most Indian customers message before they call',
        ],
      },
    ],

    local: {
      heading: 'Local search is the one service where being local counts',
      body:
        'We are based in Visnagar and set up profiles for businesses in Ahmedabad, Mehsana, across North Gujarat and the rest of India. On this service the local part is not a courtesy — **the search that matters happens in your language and your taluka**, and the words a customer types are rarely the words a business would choose for itself. We see the same result pages your customers see, which is why the category we pick is usually not the obvious one.',
      points: [
        'Categories and services chosen from what customers here actually type, not trade vocabulary',
        'Profiles written to work in English and Gujarati, including transliterated searches',
        'Hours set around festival closures and the days your market genuinely shuts',
        'Ownership transferred to your own Google account at handover, never held in ours',
      ],
      stat: { value: 'Visnagar', label: 'Based in North Gujarat, setting up profiles nationwide' },
    },

    faqNote:
      'This service attracts more exaggerated promises than any other on our list, so these answers say plainly what can be controlled, what cannot, and **what we will refuse to do for you**.',

    faqs: [
      {
        q: 'How long does Google Business Profile verification take?',
        a: 'The setup work takes one to two weeks. Verification runs on Google’s timetable, not ours, and the method is assigned by Google rather than chosen by you — video call, phone, email or postcard. Video verification is now the most common for small businesses and can be done in a single sitting if we have the right things ready: signage with your name on it, the premises, the equipment you actually work with, and something showing the address. When it goes smoothly you are verified within a few days. When Google asks for a second attempt, which happens more often than anyone admits, it can stretch to two or three weeks. We handle the submission, coach you through the recording, and re-file if it is rejected. We do not charge again for a re-file, because the failure is usually in Google’s judgement rather than your paperwork.',
      },
      {
        q: 'Will this help me rank on Google Maps?',
        a: 'It makes you eligible, which is more than most businesses currently are, and it removes the reasons Google has to rank you below someone else. Local map position is driven by relevance, distance and prominence. Relevance is category and service accuracy — we control that completely. Prominence is reviews, photos, activity, website quality and consistent details across the web — we control most of that. Distance we cannot touch. If your workshop sits four kilometres outside town, somebody searching from the market square may still see the three businesses beside them first, and no amount of optimisation changes that. What we will not do is promise a position. Anybody guaranteeing you the top of the map pack is either lying or has not read Google’s guidelines. What we can say honestly is that a complete, verified, actively maintained profile beats an empty one nearly every time, and most of your competition is running an empty one.',
      },
      {
        q: 'Do I need a website for a Google Business Profile?',
        a: 'No. The profile works without one and you can start here. But be clear about what happens next: a customer who is genuinely considering spending money will tap the website link to check you are real, and if there is nothing to tap, some of them stop. A linked website also gives Google more to verify you against, which helps prominence. So the honest order is this. If you have no digital presence at all and a limited budget, do this first — it is cheaper, faster and it reaches people at the exact moment they are ready to buy. Once enquiries start arriving, put the next money into a proper website. If you already have a website that nobody visits, this service is almost certainly the missing half, not another redesign.',
      },
      {
        q: 'How long before we actually see results?',
        a: 'Expect the first movement in two to four weeks after verification, and a fair judgement at three months. Some businesses see calls within days simply because they were previously invisible and the category was wrong. In a thin category in a small town, a properly built profile can climb quickly. In a crowded category in Ahmedabad, where every competitor already has three hundred reviews and eight years of activity, you are building position over months and reviews are what move it. Anyone quoting you a fixed timeline has not looked at your category. What we do give you is a measurable baseline before we start — current calls, direction requests, searches and photo views — so at ninety days you are comparing numbers rather than impressions. If the numbers have not moved, we would rather sit down and tell you the reason than sell you a maintenance package.',
      },
      {
        q: 'Can you get us reviews, or arrange a few to start with?',
        a: 'No. We will build the system that earns them and we will not buy, write or arrange a single one. This is not a moral lecture, it is a practical warning. Google detects purchased reviews well — a burst of five-star ratings from accounts with no history, all posted the same week, from devices nowhere near your location. The outcomes range from silent filtering, which means you paid for nothing, to a consumer alert on your listing or outright suspension, and recovering a suspended profile takes weeks you cannot afford. Customers spot them too: five reviews reading like the same person wrote them does more damage than having none. Review gating — asking only happy customers — also breaches Google’s policy. What works is unglamorous. Ask every customer at the right moment, make it one tap with a short link or QR code, and reply to every review including the bad ones. Twenty genuine reviews with real replies outperform a hundred bought ones, and they cannot be taken away from you.',
      },
      {
        q: 'What if our listing is already claimed by somebody else?',
        a: 'This is common and it is fixable. Usually it is an agency that set it up years ago, a former employee, or a staff member who used a personal account and has since left. Google has a formal ownership request process. We submit it from your account, and the current owner has seven days to respond. If they ignore it, ownership typically transfers to you. If they refuse, there is an appeal where you provide proof the business is yours — registration, utility bill, signage photographs, GST documents. Where the current holder is unreachable, that appeal is usually decided in a few weeks. What we will not do is create a second listing to work around the problem. Duplicates split your reviews and your ranking signals and invite a suspension. If you are still working with the agency that holds it, ask them for ownership in writing before anything else. A studio that refuses to hand over an asset carrying your name and address is telling you something worth knowing.',
      },
      {
        q: 'What do you need from us to start?',
        a: 'Less than you would expect, but the pieces we ask for are the ones only you can supply. Proof the business exists at the address — registration, GST certificate, a utility bill or a rent agreement — because verification eventually asks for it. Access to the phone number and email you want listed, since codes arrive there. Your exact business name as it appears on the board outside, not a decorated version with keywords added, which Google penalises. Real opening hours including the days you close. Photographs of the premises, the team and the work, even taken on a phone. A list of what you actually sell, in the words your customers use. And one person who can approve decisions and be available on a video call for around twenty minutes for verification. If photographs are the gap, tell us early. Sometimes the right first spend is a half-day shoot, not another line on our invoice.',
      },
    ],

    related: ['web-dev', 'branding', 'social'],
  },
];

/* ─── HELPERS ─────────────────────────────────────────── */
export const getServiceBySlug = (slug) => SERVICES.find((s) => s.slug === slug);
export const getServiceById = (id) => SERVICES.find((s) => s.id === id);
export const SERVICE_SLUGS = SERVICES.map((s) => s.slug);
